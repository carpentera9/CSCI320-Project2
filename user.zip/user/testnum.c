#include "kernel/types.h" 
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

#define NUM_FILES 5

int fileDescriptors[NUM_FILES] = {0};

void openFiles() {
    const char* filenames[NUM_FILES] = {
        "gfilenumtest1", "gfilenumtest2", "gfilenumtest3", "gfilenumtest4", "gfilenumtest5"
    };
    
    for (int i = 0; i < NUM_FILES; i++) {
        fileDescriptors[i] = open(filenames[i], O_CREATE | O_WRONLY);
    }
}

void closeFiles(int indices[], int numToClose) {
    for (int i = 0; i < numToClose; i++) {
        close(fileDescriptors[indices[i]]);
    }
}

int main(int argc, char **argv) {
    int pid = getpid();
    printf("files open for %d\n:", pid);
    printf("before opening any additional: %d (should be 3)\n", getfilenum(pid));

    openFiles();
    printf("opened 5: %d (should be 8)\n", getfilenum(pid));

    int closeIndices1[] = {2}; // Close fd3
    closeFiles(closeIndices1, 1);
    printf("closed 1: %d (should be 7)\n", getfilenum(pid));

    int closeIndices2[] = {0}; // Close fd1
    closeFiles(closeIndices2, 1);
    printf("closed another: %d (should be 6)\n", getfilenum(pid));

    int closeIndices3[] = {4}; // Close fd5
    closeFiles(closeIndices3, 1);
    printf("closed another: %d (should be 5)\n", getfilenum(pid));

    fileDescriptors[4] = open("gfilenmumtest6", O_CREATE | O_WRONLY);
    printf("opened 1: %d (should be 6)\n", getfilenum(pid));

    close(fileDescriptors[4]);
    close(fileDescriptors[1]);
    close(fileDescriptors[3]);
    printf("closed all: %d (should be 3)\n", getfilenum(pid));

    exit(0);
}
